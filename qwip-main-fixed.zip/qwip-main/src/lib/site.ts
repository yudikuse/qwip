export const BASE_URL = "https://qwip.pro"; // ajuste se publicar em outro domínio
